<?php
namespace App\Models;
use CodeIgniter\Model;
class Db_model extends Model
{
protected $db;



public function __construct()
{
$this->db = db_connect(); //charger la base de données
// ou
// $this->db = \Config\Database::connect();
}


// Récupère tous les comptes de la table T_compte_cpt
public function get_all_compte()
{
$resultat = $this->db->query("SELECT * FROM T_compte_cpt order by cpt_active;");
return $resultat->getResultArray();
}


 // Met à jour l'état d'un compte (cpt_active) dans la table T_compte_cpt en fonction de son ID
public function gerer_compte($etat,$id )
{
$resultat = $this->db->query("UPDATE T_compte_cpt set  cpt_active = '".$etat."' where cpt_id='".$id."';");
return $resultat;
}


 // Récupère le nombre total de comptes dans la table T_compte_cpt
public function get_nb_compte()
{
$requete="SELECT COUNT(*) as nb_compte FROM T_compte_cpt ;";
$resultat = $this->db->query($requete);
return $resultat->getRow();
}


  // Ajoute un nouveau scénario à la table T_scenario_sce
public function ajouter_scenario($intitule_sce, $desc_sce, $active_sce,$image,$id ) {
        
    $intitule = htmlspecialchars(addSlashes($intitule_sce));
        $desc = htmlspecialchars(addSlashes($desc_sce));
        $active = htmlspecialchars(addSlashes($active_sce));
     // Appel d'une procédure stockée pour générer un code
        $requ="CALL GenerateRandomCode();";
        $resulta = $this->db->query($requ);
        $code = $resulta->getRow();
    
        $sql = "INSERT INTO T_scenario_sce (sce_intitule, sce_desc, sce_active ,sce_code , sce_image, cpt_id) VALUES
            ('".$intitule."','".$desc."','".$active."','".$code->code."','".$image."','".$id."');";
        return $this->db->query($sql);
    }



/*
public function set_compte($saisie)
 {
 //Récuparation (+ traitement si nécessaire) des données du formulaire
 $login=$saisie['pseudo'];
 $mot_de_passe=$saisie['mdp'];
 $statut=$saisie['statut'];
 $sql="INSERT INTO T_compte_cpt VALUES(NULL,'".$mot_de_passe."','".$statut."','A','".$login."');";
 return $this->db->query($sql);
 }
*/

public function set_compte($saisie)
 {
 //Récuparation (+ traitement si nécessaire) des données du formulaire
 $login=$saisie['pseudo'];
 $mot_de_passe=$saisie['mdp'];
 $statut=$saisie['statut'];
 $sql="INSERT INTO T_compte_cpt VALUES(NULL,?,?,'A',?);";
 return $this->db->query($sql,[$mot_de_passe, $statut, $login]);
 }

//verification du donner pour la connection

public function connect_compte($u,$p)
    {
      
$sql="SELECT cpt_login,cpt_mdp
FROM T_compte_cpt
WHERE cpt_login='".$u."'
AND cpt_mdp=SHA2('".$p."AZERTQSDFG!!',256);";   //AND cpt_mdp=hash_mdp('".$p."');";
$resultat=$this->db->query($sql);
if($resultat->getNumRows() > 0)
       {
       return true;
       }
       else
           {
            return false;
           }
}



// recuperation du role de l'utilisateur 
public function get_compte_role($up)
{
$sql = "SELECT cpt_role FROM T_compte_cpt where cpt_login= ?;";
$resultat = $this->db->query($sql,[$up]);
$rslt = $resultat->getRow();
if($rslt)
{
    return $rslt->cpt_role; 
}
}



//afficher les détails du compte de l'organisateur
public function afficher_compte($up)
{
$sql = "SELECT cpt_role,cpt_login,cpt_active FROM T_compte_cpt where cpt_login= ?;";
$resultat = $this->db->query($sql,[$up]);
$rslt = $resultat->getRow();
if($rslt)
{
    return $rslt; 
}
}





//recuperatio des etapes en fonction du némero et niveau
public function get_etape($num_sce, $difficulte)
{
$resultat = $this->db->query("SELECT etp_desc, etp_question, ind_desc, ind_lien
FROM T_scenario_sce
JOIN T_etape_etp USING(sce_id)
LEFT JOIN T_indice_ind ON T_etape_etp.etp_id = T_indice_ind.etp_id AND ind_niveau = '$difficulte'
WHERE T_etape_etp.etp_num = 1 AND sce_code = '".$num_sce."' ;" );
return $resultat->getRow();
}




//modification du mot de passe
public function modification_mdp($u, $new_mdp)
{
  $mdp = $new_mdp;
  $set_mdp="CALL update_mdp('".$u."','".$mdp."');";
  $resultat = $this->db->query($set_mdp);
if ($resultat){
    return true;
}else{
    return false;
}
}



//recuperation de tous les scenario pour la parti visititeur
public function get_scenario()
{
$resultat = $this->db->query("SELECT sce_code , sce_intitule , cpt_login , sce_id, sce_active,sce_image FROM T_scenario_sce JOIN T_compte_cpt USING (cpt_id) where sce_active ='P';");
return $resultat->getResultArray();
}

//recuperation de tout les scenario pour la partie administrateur
public function get_scenario_organisateur()
{
$resultat = $this->db->query("SELECT sce_code  ,sce_intitule , cpt_login , sce_id, sce_active,sce_image FROM T_scenario_sce JOIN T_compte_cpt USING (cpt_id) ");
return $resultat->getResultArray();
}


//recuperation du details du scenarion avec ses étapes 

public function details_scenario($id)

    {

    $sql = "SELECT sce_intitule  ,sce_desc , sce_active , etp_code , sce_image , etp_question , etp_desc , etp_response , etp_num 
        from T_scenario_sce left join T_etape_etp using(sce_id) where sce_id ='" . $id . "' ;";

        $resultat = $this->db->query($sql);

        return $resultat->getResultArray();

    }



// Supprime un scénario de la table T_indice_ind en fonction de sce_id
public function delete_indice($id)

    {

        $sql = "DELETE FROM T_indice_ind WHERE etp_id IN (SELECT etp_id FROM T_etape_etp WHERE sce_id = '" . $id . "');";
        $resultat = $this->db->query($sql);

        return $resultat;

    }




// Supprime un scénario de la table T_etape_etp en fonction de sce_id

public function delete_etapes($id)

    {

        $sql = "DELETE FROM T_etape_etp where sce_id = '" . $id . "';";

        $resultat = $this->db->query($sql);

        return $resultat;

    }

    // Supprime un scénario de la table T_information_inf en fonction de sce_id

    public function delete_information($id)

    {

        $sql = "DELETE FROM T_information_inf where sce_id = '" . $id . "';";

        $resultat = $this->db->query($sql);

        return $resultat;

    }



    // Supprime un scénario de la table T_scenario_sce en fonction de son ID

public function delete_scenario($id)

    {

        $sql = "DELETE FROM T_scenario_sce where sce_id = '" . $id . "';";

        $resultat = $this->db->query($sql);

        return $resultat;

    }


    //verification si un scenario existe dans la base de donné

public function scenario_exists($sce_code)
{
    $sql = "SELECT sce_code from T_scenario_sce where sce_code = '".$sce_code."';";
  $resultat = $this ->db->query($sql);
  $res = $resultat->getRow();
  if ($res !== null){
    return true;
  }else{
    return Null;
  }
}

//recuperation de tous les actualite
public function get_all_actualite()
{
$requete="SELECT act_id, cpt_login, act_intitule, act_description, act_date ,act_etat From 
T_actualite_act JOIN T_compte_cpt USING (cpt_id) where act_etat = 'P';";
$resultat = $this->db->query($requete);
return $resultat->getResultArray();
}


//recuperation de l'id de l'utilisateur
public function get_id($user)
{
$requete="SELECT cpt_id FROM T_compte_cpt WHERE cpt_login='".$user."';";
$resultat = $this->db->query($requete);
return $resultat->getRow();
}



//recuperation d'un actualite en fonction de numero
public function get_actualite($numero)
{
$requete="SELECT * FROM T_actualite_act WHERE act_id=".$numero.";";
$resultat = $this->db->query($requete);
return $resultat->getRow();
}


//recuperation d'un etape en fonction de numero


public function get_next_etape($sce_id, $etp_num, $niveaudifficulte)
    {
        $resultat = $this->db->query("SELECT  sce_id, ind_desc, ind_lien, etp_id, res_chemin, ind_niveau, etp_code, etp_question, etp_desc, etp_reponse, etp_num FROM T_etape_etp 
        LEFT JOIN T_indice_ind USING(etp_id) LEFT JOIN T_ressource_res USING(res_id) WHERE etp_num = '$etp_num' AND sce_id = '$sce_id' AND ind_difficulte = '$niveaudifficulte';");
        return $resultat->getRow();
    }



}
