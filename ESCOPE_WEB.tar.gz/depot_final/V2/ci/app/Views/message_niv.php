
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Niveau invalide</title>
</head>
<body>

<h1>Niveau invalide</h1>

<p>Le niveau spécifié est invalide. Veuillez choisir un niveau entre 1 et 3.</p>

</body>
</html>
