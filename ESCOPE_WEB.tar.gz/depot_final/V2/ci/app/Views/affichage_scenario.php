<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Votre Titre</title>
    <style>
        
                /* Style pour la grille de projets */
                .grid-container {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
    grid-gap: 20px;
    background-color: #f2f2f2;
    padding: 20px;
    border-radius: 10px;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.grid-item {
    background-color: white;
    border: 1px solid #ddd;
    border-radius: 5px;
    overflow: hidden;
    transition: all 0.3s ease;
}

.grid-item:hover {
    transform: translateY(-5px);
    box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
}

.img-responsive {
    display: block;
    width: 100%;
    height: auto;
    border-bottom: 1px solid #ddd;
}

.project-description {
    padding: 15px;
}

.project-title {
    font-size: 18px;
    font-weight: bold;
    margin-bottom: 10px;
}

.project-author {
    font-size: 14px;
    color: #555;
    margin-bottom: 10px;
}

.difficulty-links {
    margin-top: 10px;
}

.difficulty-links a {
    margin-right: 10px;
    text-decoration: none;
    color: blue;
}

.difficulty-links a:hover {
    text-decoration: underline;
}
        </style>
</head>
<body>
    <br><br></br></br>
    <h2><?php echo $titre; ?></h2>
    <br><br></br></br>
    <?php
    if (!empty($SCE) && is_array($SCE)) {
        echo "<div class='grid-container'>";
        
        foreach ($SCE as $all_scenario) {
            echo "<div class='grid-item'>";
            echo "<img src='" . base_url("images/" . $all_scenario["sce_image"]) . "' alt='Image du scenario' class='img-responsive'>";
            echo "<div class='project-description'>";
            echo "<h3 class='project-title'>" . $all_scenario["sce_intitule"] . "</h3>";
            
            // Affichage de l'auteur du scénario
            echo "<p class='project-author'>Auteur: ";
            if ($all_scenario["cpt_login"] != null) {
                echo $all_scenario["cpt_login"];
            } else {
                echo "Pas d'auteur pour ce scénario";
            }
            echo "</p>";
            
            // Liens vers les niveaux de difficulté
            echo "<div class='difficulty-links'>";
	    echo "<p>Niveau : " . "<a href='" . base_url("index.php/scenario/afficher_etape/" . $all_scenario["sce_code"] . "/1") . "'>facile</a></p>";
	    echo "<p>Niveau : " . "<a href='" . base_url("index.php/scenario/afficher_etape/" . $all_scenario["sce_code"] . "/2") . "'>moyen</a></p>";
	    echo "<p>Niveau : " . "<a href='" . base_url("index.php/scenario/afficher_etape/" . $all_scenario["sce_code"] . "/3") . "'>difficile</a></p>";
            echo "</div>";
            
            echo "</div>";
            echo "</div>";
        }
        
        echo "</div>";
    } else {
        echo "<h3>Aucun scénario pour le moment</h3>";
    }
    echo"<br><br></br></br>";
    ?>
</body>
</html>
