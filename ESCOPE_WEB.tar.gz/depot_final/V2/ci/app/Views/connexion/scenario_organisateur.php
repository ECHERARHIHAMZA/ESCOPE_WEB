<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Liste des scénarios</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>
<body>
<a href="<?= site_url('/compte/creer_scenario') ?>">
    <i class="fas fa-plus-circle"></i> Ajouter un scénario
</a>

<?php
$session = session();
$user = $session->get('user');
?>

<?php if (!empty($scenarios) && is_array($scenarios)) : ?>
    <div class='table-responsive'>
        <table class='table table-bordered'>
            <thead>
                <tr>
                    <th>Code</th>
                    <th>Intitulé</th>
                    <th>Pseudo</th>
                    <th>Image</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($scenarios as $resultat) : ?>
                    <tr>
                        <td><?= $resultat['sce_code'] ?></td>
                        <td><?= $resultat['sce_intitule'] ?></td>
                        <td><?= $resultat['cpt_login'] ?></td>
                        <td><img src='<?= base_url("images/" . $resultat['sce_image']) ?>' alt='Image'></td>
                        <td>
                            <?php if ($user == $resultat['cpt_login']) : ?>
                                <form method='post' action='<?= site_url('/compte/afficher_scenario_details/') . $resultat["sce_code"] ?>'target='_blank'>
                                    <input type='hidden' name='id' value='<?= $resultat['sce_id'] ?>'>
                                    <button type='submit' name='action' value='visualiser'>Visualiser</button>
                                </form>
                                <form method='post' action='votre_action.php'>
                                    <input type='hidden' name='sce_id' value='<?= $resultat['sce_id'] ?>'>
                                    <button type='submit' name='action' value='Active/desactiver'>Active/desactiver</button>
                                </form>
                                <form id="deleteForm" method="post" action="<?= site_url('compte/delete_scenario') ?>">
                                      <input type="hidden" name="sce_id" value="<?= $resultat['sce_id'] ?>">
                                      <button type="button" onclick="confirmDelete()">Supprimer</button>
                                </form>
                                                                                                                           
                                <script>
                                 function confirmDelete() {
                                     if (confirm("Êtes-vous sûr de vouloir supprimer ce scénario ?")) {
                                         document.getElementById("deleteForm").submit();
                                              }
                                          }
                                </script>

                                <form method='post' action='votre_action.php'>
                                    <input type='hidden' name='sce_id' value='<?= $resultat['sce_id'] ?>'>
                                    <button type='submit' name='action' value='modifier'>Modifier</button>
                                </form>
                                <form method='post' action='votre_action.php'>
                                    <input type='hidden' name='sce_id' value='<?= $resultat['sce_id'] ?>'>
                                    <button type='submit' name='action' value='reset'>
                                        <i class="fas fa-sync-alt"></i>
                                    </button>
                                </form>

                            <?php else : ?>
                                <form method='post' action='<?= site_url('/compte/afficher_scenario_details/') . $resultat["sce_code"] ?>'target='_blank'>
                                    <input type='hidden' name='id' value='<?= $resultat['sce_id'] ?>'>
                                    <button type='submit' name='action' value='visualiser'>Visualiser</button>
                                </form>
                                <form method='post' action='votre_action.php'>
                                    <input type='hidden' name='sce_id' value='<?= $resultat['sce_id'] ?>'>
                                    <button type='submit' name='action' value='copier'>Copier</button>
                                </form>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
<?php else : ?>
    <p>Aucun résultat pour le moment.</p>
<?php endif; ?>

</body>
</html>


