<div class="container">
    <h1>Détails du Scénario</h1>

    <?php if (!empty($scenario)) : ?>
        <table class="table">
            <thead>
                <tr>
                    <th>Intitulé</th>
                    <th>Description</th>
                    <th>Actif</th>
                    <th>Code</th>
                    <th>Image</th>
                    <th>Question</th>
                    <th>Description Étape</th>
                    <th>Réponse</th>
                    <th>Numéro Étape</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($scenario as $etape) : ?>
                    <?php if (!is_null($etape['etp_num'])) : ?>
                        <tr>
                            <td><?= $etape['sce_intitule']; ?></td>
                            <td><?= $etape['sce_desc']; ?></td>
                            <td><?= $etape['sce_active']; ?></td>
                            <td><?= $etape['etp_code']; ?></td>
                            <td><img src='<?= base_url("images/" . $etape['sce_image']) ?>' alt='Image' width='100px' height='auto'></td>
                            <td><?= $etape['etp_question']; ?></td>
                            <td><?= $etape['etp_desc']; ?></td>
                            <td><?= $etape['etp_response']; ?></td>
                            <td><?= $etape['etp_num']; ?></td>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; ?>
            </tbody>
        </table>
    <?php endif; ?>

    <?php if (empty($scenario) || (array_column($scenario, 'etp_num') === [null])) : ?>
        <p>Aucune étape disponible pour ce scénario.</p>
    <?php endif; ?>
</div>
