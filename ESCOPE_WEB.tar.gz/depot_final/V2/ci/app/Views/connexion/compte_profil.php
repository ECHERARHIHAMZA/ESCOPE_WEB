<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Profil Utilisateur</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f7f7f7;
        }

        .container {
            max-width: 600px;
            margin: 50px auto;
            padding: 20px;
            border: 2px solid #ccc;
            border-radius: 8px;
            background-color: #fff;
        }

        .info {
            margin-bottom: 10px;
        }

        .info strong {
            display: inline-block;
            width: 100px;
            font-weight: bold;
        }

        .link {
            text-decoration: none;
            color: #007bff;
            display: block;
            margin-top: 20px;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Profil Utilisateur</h2>
    <?php if (!empty($afficher_pro)) : ?>
        <div class="info">
            <strong>Rôle:</strong>
            <span><?= $afficher_pro->cpt_role ?></span>
        </div>
        <div class="info">
            <strong>Login:</strong>
            <span><?= $afficher_pro->cpt_login ?></span>
        </div>
        <div class="info">
            <strong>Active:</strong>
            <span><?= $afficher_pro->cpt_active ?></span>
        </div>

        <!-- Formulaire pour changer le mot de passe -->
        <?php
        echo form_open('compte/modification_du_mdp'); ?>
        <?= csrf_field() ?>
        <button type="submit" class="link">Changer le mot de passe</button>
        <?= form_close(); ?>
    <?php else : ?>
        <p>Aucune information sur le profil trouvée.</p>
    <?php endif; ?>
</div>

</body>
</html>