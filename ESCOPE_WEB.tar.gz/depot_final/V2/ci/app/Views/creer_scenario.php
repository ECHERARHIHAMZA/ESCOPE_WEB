<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Ajouter un scénario</title>
    <!-- Ajoutez ici vos liens CSS ou d'autres scripts -->
</head>
<body>

<h1>Ajouter un scénario</h1>

<?php echo form_open_multipart('compte/creer_scenario'); ?>

    <label for="intitule">Intitulé :</label>
    <input type="text" name="intitule" id="intitule" required><br><br>

    <label for="description">Description :</label>
    <textarea name="description" id="description" rows="4" cols="50" required></textarea><br><br>


    <label for="etat">etat :</label>
    <select name="etat">
        <option value="P">P</option>
        <option value="C">C</option>
    </select>
    <?= validation_show_error('etat') ?>

    <label for="fichier">Image :</label>
    <input type="file" name="fichier" id="fichier" required><br><br>

    <!-- D'autres champs pour les informations du scénario -->

    <input type="submit" value="Ajouter">
    
<?php echo form_close(); ?>

</body>
</html>
