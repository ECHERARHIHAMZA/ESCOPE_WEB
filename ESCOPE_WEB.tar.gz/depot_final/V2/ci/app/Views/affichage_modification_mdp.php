<div class="container">
    <h1>Changer le mot de passe</h1>
    <?php if(session()->getFlashdata('success_message')): ?>
        <div class="alert alert-success" role="alert">
            <?= session()->getFlashdata('success_message') ?>
        </div>
    <?php endif; ?>
    <?php if(session()->getFlashdata('error_message')): ?>
        <div class="alert alert-danger" role="alert">
            <?= session()->getFlashdata('error_message') ?>
        </div>
    <?php endif; ?>
    <div class="profile-container">
        <?php
        $session = session();

        if ($afficher_pro->cpt_role == 'A') {
            $role = "Administrateur";
        } else {
            $role = "Organisateur";
        }

        echo "<h2>" . $role . "</h2>";

        if ($afficher_pro->cpt_active == "A") {
            $etat = "Activé";
        } else {
            $etat = "Désactivé";
        }

        echo "<div class='profile-item'><label class='profile-id'>Login:</label> " . $afficher_pro->cpt_login . '</div>';
        echo "<div class='profile-item'><label class='profile-id'>Role:</label> " . $role . '</div>';
        echo "<div class='state'><label class='profile-id'>Etat:</label> " . $etat . '</div>';
        ?>
    </div>
    <?php
    // Création d’un formulaire qui pointe vers l’URL de base + /compte/modification_du_mdp
    echo form_open('compte/modification_du_mdp'); ?>
    <?= csrf_field() ?>
    <div class="mb-3">
        <label for="new_password" class="form-label">Nouveau mot de passe</label>
        <input type="password" class="form-control" id="new_password" name="new_password" required>
    </div>
    <div class="mb-3">
        <label for="confirm_password" class="form-label">Confirmez le mot de passe</label>
        <input type="password" class="form-control" id="confirm_password" name="confirm_password" required>
    </div>
    <button type="submit" class="btn btn-primary">Changer le mot de passe</button>
    </form>
    <li class="nav-item">
              <a class="nav-link" href="<?php echo base_url();?>index.php/compte/afficher_profil">
                Annuler
              </a>
            </li>
</div>
