<?php
if (is_array($act) && count($act) > 0) {
    echo("<h1>Liste des Actualités</h1>");
    echo("
    <div class='table-responsive'>
        <table class='table table-bordered'>
            <thead>
                <tr>
                    <th>Intitulés</th>
                    <th>Description</th>
                    <th>Date</th>
                    <th>Auteur</th>
                </tr>
            </thead>
            <tbody>");
    
    foreach ($act as $actua) {
            echo("<tr>");
            echo("<td>".$actua['act_intitule']."</td>");
            echo("<td>".$actua['act_description']."</td>");
            echo("<td>".$actua['act_date']."</td>");
            echo("<td>".$actua['cpt_login']."</td>");
            echo("</tr>");
        
    }

    echo("
            </tbody>
        </table>
    </div>
    <br><br>");
} else {
    echo("<h3>Aucune actualité pour le moment</h3>");
}
?>
