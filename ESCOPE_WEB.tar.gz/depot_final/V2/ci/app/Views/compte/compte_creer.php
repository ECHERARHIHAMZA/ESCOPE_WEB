<h2><?php echo $titre; ?></h2>
<?= session()->getFlashdata('error') ?>
<?php echo form_open('/compte/ajouter_compte'); ?>

<?= csrf_field() ?>

<div>
    <label for="pseudo">Pseudo :</label>
    <input type="input" name="pseudo">
    <?= validation_show_error('pseudo') ?>
</div>

<div>
    <label for="mdp">Mot de passe :</label>
    <input type="password" name="mdp">
    <?= validation_show_error('mdp') ?>
</div>

<div>
    <label for="cmdp">Confirmation du Mot de passe :</label>
    <input type="password" name="cmdp">
    <?= validation_show_error('cmdp') ?>
</div>

<div>
    <label for="statut">Statut :</label>
    <select name="statut">
        <option value="A">A</option>
        <option value="O">O</option>
    </select>
    <?= validation_show_error('statut') ?>
</div>

<div>
    <input type="submit" name="submit" value="Créer un nouveau compte">
</div>

</form>
<