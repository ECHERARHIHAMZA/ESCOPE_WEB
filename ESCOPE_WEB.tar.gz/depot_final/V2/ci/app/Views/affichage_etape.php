<?php
if (!empty($etape)) {
    echo "<p style='font-weight: bold; font-size: 20px;'>" . $etape->etp_desc . "</p>";
    echo "<p style='font-size: 16px;'>" . $etape->etp_question . "</p>";

    if ($etape->ind_lien !== null && $etape->ind_lien !== '') {
        echo "<p style='font-size: 16px; color: #333; font-style: italic;'>Voici un petit indice pour vous aider : ";
        echo "<a href='" . $etape->ind_lien . "' title='Voir l'indice'>";
        echo "<i class='fa fa-search'></i>"; // Icône de la loupe
        echo "</a>";
        echo "</p>";
    } else {
        echo "<p style='font-size: 16px; color: #333; font-style: italic;'>Oups ! Il n'y a pas d'indice cette fois, tentez votre chance tout seul 😉</p>";
    }

    echo "<br>";
    echo "<input type='text' placeholder='Votre Réponse'>";
    echo "<button style='background-color: green; color: white;'>Valider</button>";
    echo "<br><br>";
} else {
    echo "Pas d'étapes !";
}
?>
