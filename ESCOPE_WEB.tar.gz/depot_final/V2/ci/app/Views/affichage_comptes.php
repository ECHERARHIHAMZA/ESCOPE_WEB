<h2><?php echo $titre; ?></h2>
<!-- Icône d'ajout de scénario -->
<a href="<?= site_url('/compte/ajouter_compte') ?>">
    <i class="fas fa-plus-circle"></i> Ajouter un compte
</a>
<?php
if (!empty($logins) && is_array($logins)) {
    echo("
    <div class='table-responsive'>
        <table class='table table-bordered'>
            <thead>
                <tr>
                    <th>Pseudo</th>
                    <th>Role</th>
                    <th>Validite</th>
                    <th>Modifier</th>
                </tr>
            </thead>
            <tbody>");

    foreach ($logins as $log) {
        echo("<tr>");
        echo("<td>" . $log['cpt_login'] . "</td>");
        echo("<td>" . $log['cpt_role'] . "</td>");
        echo("<td>" . $log['cpt_active'] . "</td>");
        echo("<td>");
        echo("<form method='post' action='" . site_url('/compte/gerer_profil') . "'>");
        echo("<input type='hidden' name='profil' value='" . $log['cpt_id'] . "'>");

        // Bouton pour activer
        echo("<button type='submit' name='action' value='A' class='btn btn-primary'>Activé</button>");

        // Bouton pour désactiver
        echo("<button type='submit' name='action' value='D' class='btn btn-danger'>Désactivé</button>");
        
        echo("</form>");
        echo("</td>");
        echo("</tr>");
    }

    echo("
            </tbody>
        </table>
    </div>
    <br><br>");
} else {
    echo("<h3>Aucun compte pour le moment</h3>");
}
?>
