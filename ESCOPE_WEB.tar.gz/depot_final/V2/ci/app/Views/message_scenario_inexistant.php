<!-- message_scenario_inexistant.php -->

<div>
    <h2>Scénario Inexistant</h2>
    <p>Le scénario que vous cherchez n'existe pas.</p>
</div>
