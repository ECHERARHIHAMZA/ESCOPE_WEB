<?php
namespace App\Controllers;
use App\Models\Db_model;
use CodeIgniter\Exceptions\PageNotFoundException;
class Scenario extends BaseController
{
public function __construct()
{
//...
}
/*
public function afficher()
{
$model = model(Db_model::class);


$data['titre']="Liste de tous Scénario";
$data['SCE'] = $model->get_scenario();
return view('templates/haut')
.view('menu_visiteur', $data)

. view('affichage_scenario')
. view('templates/bas');


}*/


public function afficher()
{
    $model = model(Db_model::class);
    $data['titre'] = "Liste de tous Scénario";
    $data['SCE'] = $model->get_scenario();

    if (empty($data['SCE'])) {
        $data['message'] = "Aucun scénario disponible pour le moment.";
        return view('templates/haut')
            . view('menu_visiteur', $data)
            . view('affichage_scenario_vide')
            . view('templates/bas');
    } else {
        return view('templates/haut')
            . view('menu_visiteur', $data)
            . view('affichage_scenario')
            . view('templates/bas');
    }
}






public function afficher_etape($num_sce = '', $difficulte = 0)
{
    $model = model(Db_model::class);
    
    if ($num_sce == '') {
        return redirect()->to('/');
    } else if ($difficulte == 0 || $difficulte > 3) {
        $data['message'] = "Ce niveau n'existe pas.";
        return view('templates/haut')
            . view('menu_visiteur', $data)
            . view('message_niv') // Affiche le message niveau invalide
            . view('templates/bas');
    } else {
        // Vérifie si le scénario existe
        if ($model->scenario_exists($num_sce)) {
            $data['etape'] = $model->get_etape($num_sce, $difficulte);

            if (empty($data['etape'])) {
                $data['message'] = "Pas d'étapes disponibles pour ce scénario ou cette difficulté.";
                return view('templates/haut')
                    . view('menu_visiteur', $data)
                    . view('affichage_etape_vide') // Affiche le message étape vide
                    . view('templates/bas');
            } else {
                return view('templates/haut')
                    . view('menu_visiteur', $data)
                    . view('affichage_etape') // Affiche les étapes
                    . view('templates/bas');
            }
        } else {
            $data['message'] = "Ce scénario n'existe pas.";
            return view('templates/haut')
                . view('menu_visiteur', $data)
                . view('message_scenario_inexistant') // Affiche le message scénario inexistant
                . view('templates/bas');
        }
    }
}



/*
public function afficher_etape($num_sce='', $difficulte=0)
{
$model = model(Db_model::class);
if ($num_sce==''){
    return redirect()->to('/');
}
else if ($difficulte==0 || $difficulte>3){
    return redirect()->to('/scenario/afficher');
}
else{
$data['etape'] = $model ->get_etape($num_sce, $difficulte);
return view('templates/haut')
.view('menu_visiteur', $data)
. view('affichage_etape')
. view('templates/bas');
}
}
*/
}