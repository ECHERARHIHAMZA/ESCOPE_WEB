<?php
namespace App\Controllers;
use App\Models\Db_model;
use CodeIgniter\Exceptions\PageNotFoundException;
class Accueil extends BaseController
{
public function afficher($donnee)
{
    
   $data['parametre_url'] = ($donnee);
   $model = model(Db_model::class);
   $data['titre'] = 'all_actualité :';
   $data['act'] = $model->get_all_actualite();

    return view('templates/haut')
    .view('menu_visiteur', $data)
    . view('affichage_accueil')
    . view('templates/bas');
}


}
?>
