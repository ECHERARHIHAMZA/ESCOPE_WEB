<?php

namespace App\Controllers;

use App\Models\Db_model;
use CodeIgniter\Exceptions\PageNotFoundException;

class Compte extends BaseController
{
	public function __construct()
	{
		helper('form');
		//$this->model = model(Db_model::class);
	}

	//ajouter session !!!!!!!!!!!!!!!!!!!!!!
	public function lister()
	{
		$model = model(Db_model::class);
		$session = session();
		$Role = $model->get_compte_role($session->get('user'));
		if ($session->has('user') && $Role === 'A') {
		$data['titre'] = "Liste de tous les comptes";
		$data['logins'] = $model->get_all_compte();
		$data['total'] = $model->get_nb_compte();
		return view('templates/haut')
			. view('menu_administrateur', $data)
			. view('affichage_comptes')
			. view('templates/bas');
		} else {
			return redirect()->to(route_to('/'));
		}
	}


	public function gerer_profil()
	{
		$model = model(Db_model::class);
		if ($this->request->getMethod() == "post") {
			$user = $this->request->getPost('profil');
			$action = $this->request->getPost('action');
			$model->gerer_compte($action, $user);
			return redirect()->to(route_to('compte/lister'));
		}
	}



	public function scenario_organisateur()
	{
		$model = model(Db_model::class);
		$session = session();
		$Role = $model->get_compte_role($session->get('user'));
		if ($session->has('user') && $Role === 'O') {
			$data['scenarios'] = $model->get_scenario_organisateur();
			return view('templates/haut')
				. view('menu_organisateur', $data)
				. view('connexion/scenario_organisateur')
				. view('templates/bas');
		} else {
			return redirect()->to(route_to('/'));
		}
	}

/*
	public function creer()
	{
		helper('form');
		$model = model(Db_model::class);
		// L’utilisateur a validé le formulaire en cliquant sur le bouton
		if ($this->request->getMethod() == "post") {
			if (!$this->validate([
				'pseudo' => 'required|max_length[255]|min_length[2]',
				'mdp' => 'required|max_length[255]|min_length[8]',
				'statut' => 'required|in_list[A,O]'
			])) {
				// La validation du formulaire a échoué, retour au formulaire !
				return view('templates/haut', ['titre' => 'Créer un compte'])
					. view('menu_visiteur')
					. view('compte/compte_creer')
					. view('templates/bas');
			}
			// La validation du formulaire a réussi, traitement du formulaire
			$recuperation = $this->validator->getValidated();
			$model->set_compte($recuperation);
			//$data['le_compte'] = $recuperation['pseudo'];
			//$data['le_message'] = "Nouveau nombre de comptes : ";
			//Appel de la fonction créée dans le précédent tutoriel :
			//$data['le_total'] = $model->get_nb_comptes();
			return view('templates/haut')
				. view('menu_visiteur')
				. view('compte/compte_succes')
				. view('templates/bas');
		}
		// L’utilisateur veut afficher le formulaire pour créer un compte
		return view('templates/ha●●●●●●●●ut', ['titre' => 'Créer un compte'])
			. view('menu_visiteur')
			. view('compte/compte_creer')
			. view('templates/bas');
	}
*/

	public function ajouter_compte()
	{
		helper('form');
		$model = model(Db_model::class);
		$session = session();
		$Role = $model->get_compte_role($session->get('user'));
	
		if ($session->has('user') && $Role === 'A') {
			if ($this->request->getMethod() == "post") {
				if (!$this->validate([
					'pseudo' => 'required|max_length[255]|min_length[2]',
					'mdp' => 'required|max_length[255]|min_length[8]',
					'cmdp' => 'required|matches[mdp]',
					'statut' => 'required|in_list[A,O]'
				], [
					'pseudo' => [
						'required' => 'Le pseudo est requis.',
						'min_length' => 'Le pseudo doit contenir au moins 2 caractères.',
						'max_length' => 'Le pseudo ne doit pas dépasser 255 caractères.'
					],
					'mdp' => [
						'required' => 'Le mot de passe est requis.',
						'min_length' => 'Le mot de passe doit contenir au moins 8 caractères.',
						'max_length' => 'Le mot de passe ne doit pas dépasser 255 caractères.'
					],
					'cmdp' => [
						'required' => 'La confirmation du mot de passe est requise.',
						'matches' => 'La confirmation du mot de passe ne correspond pas au mot de passe.'
					],
					'statut' => [
						'required' => 'Le statut est requis.',
						'in_list' => 'Le statut doit être A ou O.'
					]
				])) {
					
					// La validation du formulaire a échoué, retour au formulaire !
					return view('templates/haut', ['titre' => 'Créer un compte'])
						. view('menu_administrateur')
						. view('compte/compte_creer')
						. view('templates/bas');
				}
	
				$recuperation = $this->validator->getValidated();
				$model->set_compte($recuperation);
	
				return view('templates/haut')
					. view('menu_administrateur')
					. view('compte/compte_succes')
					. view('templates/bas');
			}
	
			return view('templates/haut', ['titre' => 'Créer un compte'])
				. view('menu_administrateur')
				. view('compte/compte_creer')
				. view('templates/bas');
		} else {
			return redirect()->to(route_to('/'));
		}
	}
	




	public function connecter()
	{
		$model = model(Db_model::class);
		// L’utilisateur a validé le formulaire en cliquant sur le bouton
		if ($this->request->getMethod() == "post") {
			if (!$this->validate([
				'pseudo' => 'required',
				'mdp' => 'required'


			])) { // La validation du formulaire a échoué, retour au formulaire !
				return view('templates/haut', ['titre' => 'Se connecter'])
				    . view('menu_visiteur')
					. view('connexion/compte_connecter')
					. view('templates/bas');
			}
			// La validation du formulaire a réussi, traitement du formulaire
			$username = $this->request->getVar('pseudo');
			$password = $this->request->getVar('mdp');
			if ($model->connect_compte($username, $password) == true) // compte 
			{
				$session = session();
				$session->set('user', $username);
				$role = $model->get_compte_role($username);
				if ($role == 'A') {
					return view('templates/haut')
						. view('menu_administrateur')
						. view('connexion/compte_accueil')
						. view('templates/bas');
				} else {
					return view('templates/haut')
						. view('menu_organisateur')
						. view('connexion/compte_accueil')
						. view('templates/bas');
				}
			} else {

				return view('templates/haut', ['titre' => 'Nom utilisateur ou mot de passe incorrete'])
					. view('menu_visiteur')
					. view('connexion/compte_connecter')
					. view('templates/bas');
			}
		}
		// L’utilisateur veut afficher le formulaire pour se conncecter
		return view('templates/haut', ['titre' => 'Se connecter'])
			. view('menu_visiteur')
			. view('connexion/compte_connecter')
			. view('templates/bas');
	}





	public function afficher_profil()
	{
		$session = session();
		if ($session->has('user')) {
			$model = model(Db_model::class);
			$data['le_message'] = "Affichage des données du profil ici !!!";
			$data['afficher_pro'] = $model->afficher_compte($session->get('user'));
			$Role = $model->get_compte_role($session->get('user'));

			$data['user_role'] = $Role; // Ajout de la variable user_role dans les données passées à la vue

			if ($Role === 'A') {
				return view('templates/haut')
					. view('menu_administrateur', $data)
					. view('connexion/compte_profil', $data) // Passage des données $data à la vue compte_profil
					. view('templates/bas');
			} else {
				return view('templates/haut')
					. view('menu_organisateur', $data)
					. view('connexion/compte_profil', $data) // Passage des données $data à la vue compte_profil
					. view('templates/bas');
			}
		} else {
			return redirect()->to(route_to('/'));
		}
	}




	public function deconnecter()
	{
		$session = session();
		$session->destroy();
		return view('templates/haut', ['titre' => 'Se connecter'])
			. view('menu_visiteur')
			. view('connexion/compte_connecter')
			. view('templates/bas');
	}




	public function modification_du_mdp()
	{
		$session = session();
		$model = model(Db_model::class);
	
		// Vérifie si l'utilisateur est connecté
		if (!$session->has('user')) {
			return redirect()->to('/');
		}
	
		if ($this->request->getMethod() === 'post') {
			// Récupération des données du formulaire
			$newPassword = $this->request->getPost('new_password');
			$confirmPassword = $this->request->getPost('confirm_password');
	
			// Validation des données du formulaire
			$validationRules = [
				'new_password' => 'required|min_length[8]|max_length[255]',
				'confirm_password' => 'required|matches[new_password]',
			];
	
			$validationMessages = [
				// Messages de validation ici...
			];
	
			if (!$this->validate($validationRules, $validationMessages)) {
				return redirect()->to('compte/modification_du_mdp')->withInput();
			}
	
			// Modification du mot de passe dans la base de données
			$user = $session->get('user');
			$result = $model->modification_mdp($user, $newPassword);
	
			if ($result) {
				// Mot de passe modifié avec succès
				return redirect()->to('/compte/afficher_profil')->with('success_message', 'Mot de passe changé avec succès.');
			} else {
				// Échec de la modification du mot de passe
				return redirect()->to('compte/modification_du_mdp')->with('error_message', 'Échec du changement de mot de passe.');
			}
		} else {
			// Affichage du formulaire de modification de mot de passe
			$data['le_message'] = "Affichage des données du profil ici !!!";
			$data['afficher_pro'] = $model->afficher_compte($session->get('user'));
			$userRole = $model->get_compte_role($session->get('user'));
	
			// Choix de la vue en fonction du rôle de l'utilisateur
			if ($userRole === 'A') {
				return view('templates/haut')
					. view('menu_administrateur', $data)
					. view('affichage_modification_mdp')
					. view('templates/bas');
			} else {
				return view('templates/haut')
					. view('menu_organisateur', $data)
					. view('affichage_modification_mdp')
					. view('templates/bas');
			}
		}
	}





	public function afficher_scenario_details($code = '')
{
    $session = session();
    $model = model(Db_model::class);
    $Role = $model->get_compte_role($session->get('user'));

    if ($session->has('user') && $Role === 'O') {
        $id = $this->request->getPost('id'); // Récupère l'ID envoyé via POST

        $data['scenario'] = $model->details_scenario($id);
    if($data['scenario']==NULL){
		return view('templates/haut')
                . view('menu_organisateur', $data)
				. view('message_scenario_inexistant')
				. view('templates/bas');
	}
        if (!empty($id)) {
            return view('templates/haut')
                . view('menu_organisateur', $data)
                . view('connexion/affichage_scenario_compte')
                . view('templates/bas');
        }
    } else {
        return redirect()->to('/');
    }
}











/*

	public function afficher_scenario_details($code = '')
	{
		$session = session();
		$model = model(Db_model::class);
		$Role = $model->get_compte_role($session->get('user'));
		if ($session->has('user')&&  $Role === 'O') {
		
			if ($code == '')
{
	return redirect() ->to ('/compte/afficher_scenario_details');
}

			$id = $this->request->getGet('id');

			$data['scenario'] = $model->details_scenario($id);

			if (!empty($id)) {

				return view('templates/haut')

					. view('menu_organisateur', $data)

					. view('connexion/affichage_scenario_compte')

					. view('templates/bas');
			}
		}else{
			return redirect()->to('/');
		}
	}

	*/

	public function delete_scenario()
	{
		$session = session();
		if ($session->has('user')) {
			$model = model(Db_model::class);
			$id = $this->request->getPost('sce_id');

			if ($this->request->getMethod() == "post") {
				// Suppression des indices associés à l'étape
				$model->delete_information($id);

				$model->delete_indice($id);

				// Suppression des étapes associées au scénario
				$model->delete_etapes($id);

				// Suppression du scénario lui-même
				$model->delete_scenario($id);

				return redirect()->back();
			}
		}
	}





   
   
    
  public function creer_scenario()
  {
          helper('form');
          $session = session();
          if ($session->has('user')) {
                  $model = model(Db_model::class);
				  $username=$session->get('user');
				  $session->set('user', $username);
				  $role = $model->get_compte_role($username);
                  if ($role == 'O') {
                          if ($this->request->getMethod() == "post") {
                                  if (!$this->validate([
                                          'intitule' => 'required|max_length[255]|min_length[2]',
                                          'description' => 'required|max_length[255]|min_length[8]',
                                          'etat' => 'required|max_length[255]|min_length[1]',
                                          'fichier' => [
                                                  'label' => 'Fichier image',
                                                  'rules' => [
                                                          'uploaded[fichier]',
                                                          'is_image[fichier]',
                                                          'mime_in[fichier,image/jpg,image/jpeg,image/gif,image/png,image/webp]',
                                                          'max_size[fichier,100]',
                                                          'max_dims[fichier,1024,768]',
                                                  ]
                                          ]

                                  ])) {
                                          // La validation du formulaire a échoué, retour au formulaire !
                                          return   view('templates/haut')
										          .view('menu_organisateur', ['titre' => 'Créer un nouveau scenario ERREUR DE FORMILAIRE  '])
                                                  . view('creer_scenario')
                                                  . view('templates/bas');
                                     }

                                     $recuperation = $this->validator->getValidated();
                                     $intitule_sce = $recuperation['intitule'];
                                     $desc_sce = $recuperation['description'];
                                     $active_sce = $recuperation['etat'];
									 $id=$model->get_id($username);

                                   $image = $this->request->getFile('fichier');
                                  if (!empty($image)) {
                                          // Récupération du nom du fichier téléversé
                                  
                                          $nom_image = $image->getName();
                                          // Dépôt du fichier dans le répertoire ci/public/images
                                          if ($image->move("images", $nom_image)) {
                                                  $model->ajouter_scenario($intitule_sce, $desc_sce, $active_sce,$nom_image,$id->cpt_id );
                                                  $data['titre'] = "Liste de tous les scenario";
                                                  $data['logins'] = $model->get_scenario();
                                                  return  view('templates/haut')
												          .view('menu_organisateur', $data)
                                                          . view('connexion/affichage_scenario_compte')
                                                          . view('templates/bas');
                                          }

                                  }
                          }
                                  return  view('templates/haut')
								          . view('menu_organisateur', ['titre' => 'Créer un scenario'])
                                          . view('creer_scenario')
                                          . view('templates/bas');
                          
                  }
                  // L’utilisateur veut afficher le formulaire pour créer un compte
                  return redirect('/compte/afficher_profil');
          } else {
                  return view('templates/haut', ['titre' => 'Se connecter'])
				          . view('menu_visiteur')
                          . view('connexion/compte_connecter')
                          . view('templates/bas');
          }
        }

}
