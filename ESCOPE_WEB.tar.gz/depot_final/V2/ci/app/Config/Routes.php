<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
$routes->get('/', 'Accueil::afficher/');

use App\Controllers\Accueil;
$routes->get('accueil/afficher', [Accueil::class, 'afficher']);
$routes->get('accueil/afficher/(:segment)', [Accueil::class, 'afficher']);



use App\Controllers\Compte;
$routes->get('compte/lister', [Compte::class, 'lister']);
//$routes->get('compte/creer', [Compte::class, 'creer']); 
//$routes->post('compte/creer', [Compte::class, 'creer']);
$routes->get('compte/connecter', [Compte::class, 'connecter']);
$routes->post('compte/connecter', [Compte::class, 'connecter']);
$routes->post('compte/gerer_profil', [Compte::class, 'gerer_profil']);
$routes->get('compte/deconnecter', [Compte::class, 'deconnecter']);
$routes->get('compte/afficher_profil', [Compte::class, 'afficher_profil']);
$routes->match(['get', 'post'], 'compte/modification_du_mdp', [Compte::class, 'modification_du_mdp']);
$routes->get('compte/scenario_organisateur', [Compte::class, 'scenario_organisateur']);
$routes->get('compte/afficher_scenario_details', [Compte::class, 'afficher_scenario_details']);
$routes->get('compte/afficher_scenario_details/(:segment)', [Compte::class, 'afficher_scenario_details']);
$routes->post('compte/afficher_scenario_details/(:segment)', [Compte::class, 'afficher_scenario_details']);

$routes->post('compte/delete_scenario', [Compte::class, 'delete_scenario']);
$routes->get('compte/ajouter_compte', [Compte::class, 'ajouter_compte']);
$routes->post('compte/ajouter_compte', [Compte::class, 'ajouter_compte']);
$routes->get('compte/creer_scenario', [Compte::class, 'creer_scenario']);
$routes->post('compte/creer_scenario', [Compte::class, 'creer_scenario']);



use App\Controllers\Actualite;
$routes->get('actualite/afficher', [Actualite::class, 'afficher']);
$routes->get('actualite/afficher/(:num)', [Actualite::class, 'afficher']);


use App\Controllers\Scenario;
$routes->get('scenario/afficher_etape', [Scenario::class, 'afficher']);
$routes->get('scenario/afficher_etape/(:segment)', [Scenario::class, 'afficher']);
$routes->get('scenario/afficher_etape/(:segment)/(:num)', [Scenario::class, 'afficher_etape']);
