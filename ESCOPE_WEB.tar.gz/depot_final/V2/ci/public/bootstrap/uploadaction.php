<?php
echo ("Page Web OK");
// Connexion à la base MariaDB
$mysqli = new mysqli('localhost','e21908486sql','vn!EPfBe','e21908486_db1');
if ($mysqli->connect_errno) {
 //...
 }

//$uploaddir = '/home/2023DIFAL3/e21908486/public_html/gabarit/documents/';
$uploaddir = __DIR__. '/documents/';
$uploadfile = $uploaddir . basename($_FILES['userfile']['name']);
echo $uploadfile;
echo '<pre>';
if (move_uploaded_file($_FILES['userfile']['tmp_name'], $uploadfile)) {
 echo "Le fichier est valide, et a été téléchargé
 avec succès. Voici plus d'informations :\n";
 $requete = "UPDATE T_scenario_sce SET sce_image='".$_FILES['userfile']['name']."'WHERE sce_id='1'";
 $mysqli->query($requete);
 } else {
 echo "Le fichier n’a pas été téléchargé. Il y a eu un problème !\n";
}
echo 'Voici quelques informations sur le téléversement :';
print_r($_FILES);
//Fermeture de la communication avec la base MariaDB
$mysqli->close();
?>

